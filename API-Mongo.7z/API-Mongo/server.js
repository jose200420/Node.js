// server.js

// 1. IMPORTACIONES
const express = require('express');
const path = require('path');
const { connectToDb } = require('./db');

const productosRoutes = require('./routes/productos');
const clientesRoutes = require('./routes/clientes');
const pedidosRoutes = require('./routes/pedidos');

// 2. CONFIGURACIÓN DE LA APP Y MIDDLEWARE
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware para parsear JSON
app.use(express.json());

// ¡MUY IMPORTANTE! Middleware para servir archivos estáticos DEBE ir antes que las rutas.
app.use(express.static(path.join(__dirname, 'public')));

// 3. CONEXIÓN Y DEFINICIÓN DE RUTAS
connectToDb().then(() => {
    console.log('Conectado exitosamente a MongoDB');

    // Rutas de la API (deben ir antes que la ruta comodín)
    app.use('/api/productos', productosRoutes);
    app.use('/api/clientes', clientesRoutes);
    app.use('/api/pedidos', pedidosRoutes);

    // La ruta comodín DEBE ir al final de todo.
    // Usa una expresión regular para máxima compatibilidad.
    app.get(/.*/, (req, res) => {
        res.sendFile(path.join(__dirname, 'public', 'index.html'));
    });

    // 4. INICIAR SERVIDOR
    app.listen(PORT, () => {
        console.log(`Servidor corriendo en http://localhost:${PORT}`);
    });

}).catch(err => {
    console.error('No se pudo iniciar el servidor', err);
});