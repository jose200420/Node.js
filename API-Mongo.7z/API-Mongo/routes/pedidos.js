// routes/pedidos.js
const express = require('express');
const { ObjectId } = require('mongodb');
const { getDb } = require('../db');

const router = express.Router();

// GET /api/pedidos
router.get('/', async (req, res) => {
  try {
    const db = getDb();
    const pedidos = await db.collection('pedidos').find({}).toArray();
    res.status(200).json(pedidos);
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener los pedidos' });
  }
});

// GET /api/pedidos/:id
router.get('/:id', async (req, res) => {
  try {
    const db = getDb();
    const pedido = await db.collection('pedidos').findOne({ _id: new ObjectId(req.params.id) });
    if (pedido) {
      res.status(200).json(pedido);
    } else {
      res.status(404).json({ error: 'Pedido no encontrado' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Error al obtener el pedido' });
  }
});

// POST /api/pedidos
router.post('/', async (req, res) => {
  try {
    const db = getDb();
    const nuevoPedido = req.body;
    const resultado = await db.collection('pedidos').insertOne(nuevoPedido);
    res.status(201).json(resultado);
  } catch (err) {
    res.status(500).json({ error: 'Error al crear el pedido' });
  }
});

// PUT /api/pedidos/:id
router.put('/:id', async (req, res) => {
  try {
    const db = getDb();
    const actualizaciones = req.body;
    const resultado = await db.collection('pedidos').updateOne(
      { _id: new ObjectId(req.params.id) },
      { $set: actualizaciones }
    );
    if (resultado.matchedCount > 0) {
      res.status(200).json({ message: 'Pedido actualizado correctamente' });
    } else {
      res.status(404).json({ error: 'Pedido no encontrado' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Error al actualizar el pedido' });
  }
});

// DELETE /api/pedidos/:id
router.delete('/:id', async (req, res) => {
  try {
    const db = getDb();
    const resultado = await db.collection('pedidos').deleteOne({ _id: new ObjectId(req.params.id) });
    if (resultado.deletedCount > 0) {
      res.status(200).json({ message: 'Pedido eliminado correctamente' });
    } else {
      res.status(404).json({ error: 'Pedido no encontrado' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Error al eliminar el pedido' });
  }
});

module.exports = router;