// db.js
const { MongoClient } = require('mongodb');
require('dotenv').config();

const uri = process.env.MONGO_URI;
const client = new MongoClient(uri);

let db;

const connectToDb = async () => {
  try {
    await client.connect();
    db = client.db('EcommerceDB'); // Selecciona la base de datos
    console.log('Conectado exitosamente a MongoDB');
  } catch (err) {
    console.error('Fallo en la conexión a MongoDB', err);
    process.exit(1); // Termina el proceso si no se puede conectar
  }
};

const getDb = () => {
  if (!db) {
    throw new Error('Base de datos no inicializada. Llama a connectToDb primero.');
  }
  return db;
};

module.exports = { connectToDb, getDb };